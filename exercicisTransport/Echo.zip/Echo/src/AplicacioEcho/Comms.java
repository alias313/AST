/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package AplicacioEcho;

/**
 *
 * @author usuari.aula
 */
public interface Comms {
    public static final int PORT_SERVIDOR = 2222;
    public static final String IP_SERVIDOR = "localhost";    
}
