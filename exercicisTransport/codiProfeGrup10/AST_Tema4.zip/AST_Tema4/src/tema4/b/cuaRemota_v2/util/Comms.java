package tema4.b.cuaRemota_v2.util;

/**
 *
 * @author juanluis
 */
public interface Comms {
    String HOST = "127.0.0.1";
    int    PORT = 2000;
}
