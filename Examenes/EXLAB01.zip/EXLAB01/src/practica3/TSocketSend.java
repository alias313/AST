package practica3;

import utils.Const;
import utils.TCPSegment;
import utils.TSocket_base;
import utils.SimNet;

public class TSocketSend extends TSocket_base {

    protected int MSS;       // Maximum Segment Size

    public TSocketSend(SimNet net) {
        super(net);
        //MSS = net.getMTU() - Const.IP_HEADER - Const.TCP_HEADER;
        MSS = 13;
        //Completar
    }

    @Override
    public void sendData(byte[] data, int offset, int length) {
        //Completar
    }

    protected TCPSegment segmentize(byte[] data, int offset, int length) {
        //Completar
    }

}
