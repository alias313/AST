package P2;

public class GestorPool {

    private final int NR = 5;
    //Completar

    public void demana(int tipus) {
        //Completar
    }

    public void allibera(int tipus) {
        //Completar
    }

}
