package practica4;

import util.Protocol_base;
import util.TCPSegment;
import util.SimNet;
import util.TSocket_base;

public class Protocol extends Protocol_base {

    public Protocol(SimNet net) {
      super(net);
    }

    protected void ipInput(TCPSegment seg) {
        //Completar
    }

    protected TSocket_base getMatchingTSocket(int localPort, int remotePort) {
        //Completar
    }
}
