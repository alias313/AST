package practica4;

import java.util.Iterator;
import util.Queue;

public class CircularQueue<E> implements Queue<E> {

    //Completar
}
